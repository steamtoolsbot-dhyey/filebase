-- 1402320's Lua and Manifest Created by Hubcap Manifest
-- Medal of Honor™: Above and Beyond
-- Created: September 30, 2025 at 00:10:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1402320) -- Medal of Honor™: Above and Beyond
-- MAIN APP DEPOTS
addappid(1402321, 1, "59551c0e72daf61029457f14cdfddda74bdf53df1b099d0356bbd79bb7c511ed") -- R6 Content
setManifestid(1402321, "9154068945774264997", 184552812321)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)