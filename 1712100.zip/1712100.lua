-- 1712100's Lua and Manifest Created by Hubcap Manifest
-- Carmageddon: Rogue Shift
-- Created: April 03, 2026 at 16:06:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1712100, 1, "2e38c8eefbd5b3305c9f5cda00959813769061efe32e6c317f5382c7ac871cc3") -- Carmageddon: Rogue Shift
-- MAIN APP DEPOTS
addappid(1712101, 1, "0f5ee71fdc07136d363d44242df487ac0a5c6d831a49361c3fda646388c23f88") -- Depot 1712101
setManifestid(1712101, "6703802728768203287", 33617962649)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)