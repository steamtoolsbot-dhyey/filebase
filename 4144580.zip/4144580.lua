-- 4144580's Lua and Manifest Created by Hubcap Manifest
-- Christian Mother
-- Created: May 14, 2026 at 06:21:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4144580) -- Christian Mother
-- MAIN APP DEPOTS
addappid(4144581, 1, "95b3e0e70197fcebdaee8bdebcb8d4ecf5f186ebad0386cd9b48e5bce13e91ad") -- Depot 4144581
setManifestid(4144581, "8934412880973476438", 717649212)