-- 1634080's Lua and Manifest Created by Hubcap Manifest
-- Nocturnal
-- Created: April 25, 2026 at 13:46:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1634080, 1, "76d9c2e4bcb4445eb895eb858655796c305706b45bcd02959e8e350eeebc1ea2") -- Nocturnal
-- MAIN APP DEPOTS
addappid(1634081, 1, "8405535fc21af6105c678a42b5ced6ab924cfa76e6b2f6347c52ffcef68b38a3") -- Depot 1634081
setManifestid(1634081, "3992188175954551148", 1142178953)
-- DLCS WITH DEDICATED DEPOTS
-- Nocturnal - Artbook (AppID: 2827700)
addappid(2827700)
addappid(2827700, 1, "6c4c9cd7756e0001c2e84168bd39c91dc4fbb2c6519cb5b318c1aa3a4817e13a") -- Nocturnal - Artbook - Depot 2827700
setManifestid(2827700, "5455805582918180206", 194244953)