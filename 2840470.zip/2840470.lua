-- 2840470's Lua and Manifest Created by Hubcap Manifest
-- SimplePlanes 2
-- Created: April 27, 2026 at 13:15:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2840470) -- SimplePlanes 2
-- MAIN APP DEPOTS
addappid(2840471, 1, "1849882c014676488fe6b3e4ac5a33a61ee95e803353a176bd37243396d1d137") -- Depot 2840471
setManifestid(2840471, "1378061969111111748", 0)
addappid(2840472, 1, "8684d95bf48a00217eec9db68b71fafb1f80c2871f9a882c5f10e3f8e4550b52") -- Depot 2840472
setManifestid(2840472, "316160725306030640", 3958424876)
addappid(2840473, 1, "9ba75c82180014bb943ec67d908f59d13814ce38bfc808f853fe7121e567bac5") -- Depot 2840473
setManifestid(2840473, "7626725061696718641", 4112782847)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)