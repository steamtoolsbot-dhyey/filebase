-- 620's Lua and Manifest Created by Hubcap Manifest
-- Portal 2
-- Created: September 30, 2025 at 07:36:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 7

-- MAIN APPLICATION
addappid(620, 1, "a33ddcda802d5d2db32b70ce263fe29efdcef1f2e534c5d4e7f515a20b31b6a5") -- Portal 2
-- MAIN APP DEPOTS
addappid(624, 1, "48fcb7e647902c2d9467ef3f4405e1b6308981949705cb2b7489bb3d22aead66") -- portal 2 client binaries
setManifestid(624, "8323957709516641347", 20560160)
addappid(623, 1, "6a9fe60f83046355da81ea12f8fe895e3f59f1223d1689cc7e1ba327358e99fb") -- portal 2 mac content
setManifestid(623, "2276453204441793614", 126780604)
addappid(622, 1, "0be76bef0b464b2d58b6ced70c86e608708c18c1204836cb1bb5d209776f8a0e") -- portal 2 win content
setManifestid(622, "5403637970672788159", 62727638)
addappid(621, 1, "d2718f2424c94832a7112661774d98ffb3d52f454312f543a71418d253100d1d") -- portal 2 common
setManifestid(621, "3111897107378205370", 12673304378)
addappid(625, 1, "d120d4c37faea11be77c787dc48000f297aaf8200a4265969a4f5dbeebc0326c") -- Portal 2 French
setManifestid(625, "1128685895801277145", 776737924)
addappid(626, 1, "50611154e0550112cb9f9edcc44cf32bb90a7fe8d2f5738f6f24b7ced43cf7c2") -- Portal 2 German
setManifestid(626, "6439173920052159773", 724550611)
addappid(627, 1, "4ff7fb0bde51bae4f2c7a9bb220fd2da9bd9b3b8210d222c615acf28a8fdd821") -- Portal 2 Spanish
setManifestid(627, "4705364648410025995", 730398400)
addappid(628, 1, "7f299ff4eec6b9de24869bb482a325b72f792798c87268f03feda25d4f3361c5") -- Portal 2 Russian
setManifestid(628, "1134745004760172192", 745154781)
addappid(661, 1, "5e338dd8d07e4cda5dfbcc7eb03418d9b1d93192bc20d5aac2174b851b11c1a6") -- Portal 2 linux content
setManifestid(661, "8787172582039049173", 96297717)
-- DLCS WITH DEDICATED DEPOTS
-- Portal 2 Sixense MotionPack (AppID: 660)
addappid(660)
addappid(660, 1, "759d2251fd0bb050f088c166dc269ea869ddafde525032db3095fbf06cc0dfc3") -- Portal 2 Sixense MotionPack - Portal 2 - Sixense Motion
setManifestid(660, "2679694482538379167", 744014914)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(650) -- Portal 2 - Gamestop PS3 DLC
addappid(651) -- Portal 2 - Bot Paint Job DLC
addappid(652) -- Portal 2 - Bot Roll Cage DLC
addappid(653) -- Portal 2 - Bot Antenna Topper DLC
addappid(654) -- Portal 2 - Summer 2011 DLC
addappid(669) -- Portal 2 - Sixense Motion Preorder