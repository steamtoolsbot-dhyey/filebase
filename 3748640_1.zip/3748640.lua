-- 3748640's Lua and Manifest Created by Hubcap Manifest
-- Wasteland Bites
-- Created: April 19, 2026 at 20:37:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3748640, 1, "268f5b12cba4573cffcc7d909f628f6894de7debeb4b7cc14062aea911a8efd2") -- Wasteland Bites
-- MAIN APP DEPOTS
addappid(3748641, 1, "5b17fc5eac473f7fb9508b6274714c4a49de9887bed04dc8151f0b22f5fa6e48") -- Depot 3748641
setManifestid(3748641, "4381565785628729656", 599720884)
addappid(3748642, 1, "421ef8a5508d474bf7c1d6ea98d13a13a02c3d93b1c702c435fd2aaadaec7dfe") -- Depot 3748642
setManifestid(3748642, "3731837006658804027", 541816912)
addappid(3748643, 1, "8c39bf1f2888c08d2d9471ff04ff3f75b9149f4f5f88c1a7463409e43a8b886a") -- Depot 3748643
setManifestid(3748643, "5567886034169258264", 653177572)