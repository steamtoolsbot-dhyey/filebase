-- 3877070's Lua and Manifest Created by Hubcap Manifest
-- Midnight Sin
-- Created: June 03, 2026 at 02:44:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(3877070) -- Midnight Sin
-- MAIN APP DEPOTS
addappid(3877071, 1, "53018d8a500b108f6c764d0685fcda93c46d14b111267561978300fa8ac6e409") -- Depot 3877071
setManifestid(3877071, "4163601683092297501", 3707676293)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Midnight Sin - High-res character wallpapers (AppID: 4758250) - missing depot keys
-- addappid(4758250)