-- 3137350's Lua and Manifest Created by Hubcap Manifest
-- Motion Soccer
-- Created: May 11, 2026 at 15:28:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3137350) -- Motion Soccer
-- MAIN APP DEPOTS
addappid(3137351, 1, "2bb669932b7cf25317e237bf24377236c0ec3d19f455e83e0b178d0d8ddd8e95") -- Depot 3137351
setManifestid(3137351, "5287102894591794565", 2962532459)