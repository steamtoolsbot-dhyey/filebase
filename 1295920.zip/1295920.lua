-- 1295920's Lua and Manifest Created by Hubcap Manifest
-- The Mortuary Assistant
-- Created: October 26, 2025 at 11:09:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1295920) -- The Mortuary Assistant
-- MAIN APP DEPOTS
addappid(1295921, 1, "6b61d645efde65dcb14c38641fec46ad7296e8fc2ae9343a376f37c5031850b0") -- Depot 1295921
setManifestid(1295921, "6415553134461353835", 5128773863)