-- 3167280's Lua and Manifest Created by Hubcap Manifest
-- Ikarus Parkour
-- Created: April 18, 2026 at 09:23:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3167280) -- Ikarus Parkour
-- MAIN APP DEPOTS
addappid(3167281, 1, "1b1929846ec645ef5eb073427b69f02c9876da76886a8e07b53365296d852d77") -- Depot 3167281
setManifestid(3167281, "8471431780934980678", 4120942035)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)