-- 4119160's Lua and Manifest Created by Hubcap Manifest
-- An Easter to Remember
-- Created: April 29, 2026 at 08:06:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4119160) -- An Easter to Remember
-- MAIN APP DEPOTS
addappid(4119161, 1, "12cd4b5648b83b5dcf59a5e147e5cabd7346864ef0872d00222a72913c6ba1f1") -- Depot 4119161
setManifestid(4119161, "1470240227403076013", 861121821)
addappid(4119162, 1, "2a47d194a6a49a866af75f7028cf077b05b73f7616d17ef570ed295f13511bf8") -- Depot 4119162
setManifestid(4119162, "1402192147766776226", 1188906046)
addappid(4119163, 1, "b4cc9e7529f710b1e65540c135ffcf85099fdce90af6922576b8f1f70aeb739c") -- Depot 4119163
setManifestid(4119163, "9026587742309927784", 853957844)