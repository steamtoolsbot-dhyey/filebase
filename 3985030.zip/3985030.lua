-- 3985030's Lua and Manifest Created by Hubcap Manifest
-- Air Defender
-- Created: May 28, 2026 at 05:33:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3985030) -- Air Defender
-- MAIN APP DEPOTS
addappid(3985031, 1, "b61cb556d1a111c34e0504e8c767d4eeb6bb97043feb5faad9c06a7bb1b57518") -- Depot 3985031
setManifestid(3985031, "8489025195769931618", 1114572108)