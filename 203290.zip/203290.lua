-- 203290's Lua and Manifest Created by Hubcap Manifest
-- America's Army: Proving Grounds
-- Created: January 26, 2026 at 21:50:40 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 1
-- Shared Depots: 7

-- MAIN APPLICATION
addappid(203290, 1, "0460aaffa4ae9f2d3b734595f3bee830c710338dd7fbc71d1532789e051e96eb") -- America's Army: Proving Grounds
-- MAIN APP DEPOTS
addappid(203291, 1, "f10dca0216bdf63c23f9446995635c3b124093a4d77d42ba6b8ff512031408e3") -- Recon 4 Content
setManifestid(203291, "9174805395719350969", 19180717604)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- PhysX System Software 9.12.1031 (Shared from App 228980)
setManifestid(229031, "7746630274301172884", 26729083)
-- DLCS WITH DEDICATED DEPOTS
-- Americas Army Proving Grounds Editor (AppID: 399680)
addappid(399680)
addappid(399680, 1, "be52d87ddd5d0486deca33884b68033aadfff82a4c5ca650c67051ace3ab329a") -- Americas Army Proving Grounds Editor - America's Army: Proving Grounds Editor (399680) Depot
setManifestid(399680, "535626579012519329", 409532509)