-- 2873660's Lua and Manifest Created by Hubcap Manifest
-- Global Rescue
-- Created: April 27, 2026 at 11:05:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2873660) -- Global Rescue
-- MAIN APP DEPOTS
addappid(2873661, 1, "0a5e3870682953d3868752e1cf1372d20e31a16c6d2022a9ecda434642917f07") -- Depot 2873661
setManifestid(2873661, "3609214187952546638", 3679951483)