-- 4311860's Lua and Manifest Created by Hubcap Manifest
-- Ana's Auto Fellatio
-- Created: May 02, 2026 at 15:14:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(4311860, 1, "353ddea9796428495260dd52322c1dd8dddc317f736bf6656ae99cb31305aaef") -- Ana's Auto Fellatio
-- MAIN APP DEPOTS
addappid(4311861, 1, "b54b7d2712e5c8cb1d86256bf9a0d3a581776e92baf970e604790664893f581d") -- Depot 4311861
setManifestid(4311861, "5864416667316542883", 1168779941)
-- DLCS WITH DEDICATED DEPOTS
-- Anas Auto Fellatio - Art Pack (AppID: 4349790)
addappid(4349790)
addappid(4349790, 1, "b172b24709d34ccd788994d6c810387ccfc427a29da261012a2e80e80634d112") -- Anas Auto Fellatio - Art Pack - Depot 4349790
setManifestid(4349790, "4667113781583516310", 1258275513)
-- Anas Auto Fellatio - Walkthrough And Cheats (AppID: 4349800)
addappid(4349800)
addappid(4349800, 1, "6ef3574949ffa89195459570cef3e132e1c5248bf3ed6d88ec6c72310a6ff108") -- Anas Auto Fellatio - Walkthrough And Cheats - Depot 4349800
setManifestid(4349800, "4438815286513143060", 4862005)