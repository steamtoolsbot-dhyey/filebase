-- 1145360's Lua and Manifest Created by Hubcap Manifest
-- Hades
-- Created: September 29, 2025 at 16:30:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1145360) -- Hades
-- MAIN APP DEPOTS
addappid(1145361, 1, "e7db1a4f43363b9d751ed9e888334353425704ea0db26c8434015e516a482f4d") -- Content
setManifestid(1145361, "5173085471687919135", 11406885121)
addappid(1145363, 1, "b88219eb2aee190d115e532ef9feea08c69bbc53bb1f959a2c48f3739f871b31") -- Win Release
setManifestid(1145363, "2572656066874346283", 492759128)
addappid(1145364, 1, "c70c6707a01507e124d35ac0e1644ee6210f383a1ae759aa252478cbd1ca7e0e") -- macOS
setManifestid(1145364, "6896671991921324741", 11477880344)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)