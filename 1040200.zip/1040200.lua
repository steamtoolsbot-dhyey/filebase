-- 1040200's Lua and Manifest Created by Hubcap Manifest
-- Crime Scene Cleaner
-- Created: April 10, 2026 at 11:23:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(1040200, 1, "3651c051a4a7c98a872929fc9e2994273629bf6724ec207f61fd933dc702bd01") -- Crime Scene Cleaner
-- MAIN APP DEPOTS
addappid(1040201, 1, "c674332af23f9b6fcc58092e93db43d62fe38a9b004985697e490bde97b45548") -- Depot 1040201
setManifestid(1040201, "4194383657984755671", 55887217668)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4492060) -- DLC 4492060 (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4492060) -- Depot 4492060 (empty depot)