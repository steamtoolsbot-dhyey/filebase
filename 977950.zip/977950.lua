-- 977950's Lua and Manifest Created by Hubcap Manifest
-- A Dance of Fire and Ice
-- Created: February 01, 2026 at 12:00:59 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(977950, 1, "900c284c78f11289033d308ddc33fcb65659b670bd2f3684b07c15180e02e971") -- A Dance of Fire and Ice
-- MAIN APP DEPOTS
addappid(977951, 1, "5e954d77ef1866e557c00b742437d480a7c03c2303b6a96268fbd1a55014839e") -- A Dance of Fire and Ice Windows 32-bit
setManifestid(977951, "1864486839987466459", 2560705385)
addappid(977953, 1, "cff06fc131de80d2131b228a0ec443303aa7b4fa8bf9b71b02ce9faa59f005c2") -- A Dance of Fire and Ice Windows 64-bit
setManifestid(977953, "4858211432244671991", 2573784537)
addappid(977952, 1, "7161eb622ca30debeb61bc87ecc80dd9a4cf78b7ef999fbc676710acd080565e") -- A Dance of Fire and Ice macOS
setManifestid(977952, "5626107697472234499", 2582974901)
addappid(977954, 1, "85480edfffe7849f3714592a16a8fb97e94bb7fdc0773a9d9db0f80a40890bce") -- Depot 977954
setManifestid(977954, "9023192970703062894", 2605358694)
-- DLCS WITH DEDICATED DEPOTS
-- A Dance of Fire and Ice - Neo Cosmos (AppID: 1977570)
addappid(1977570)
addappid(1977571, 1, "a4ec8a574d6949e27a066e3ef02d87d50cc32e090944d977595132716b46ed40") -- A Dance of Fire and Ice - Neo Cosmos - Depot 1977571
setManifestid(1977571, "4882028131885657137", 434136208)
addappid(1977572, 1, "b0d89adeb9338cee8859eb5596cfad872bdf7a96c8e58f53cb8f214857e5c481") -- A Dance of Fire and Ice - Neo Cosmos - Depot 1977572
setManifestid(1977572, "426154061728283101", 434136208)
addappid(1977573, 1, "51140ab9601562c890952d5b7022bc09726be1e7fc6d8dbbfc09f5318110f6f7") -- A Dance of Fire and Ice - Neo Cosmos - Depot 1977573
setManifestid(1977573, "8833135426156357397", 434304544)
addappid(1977574, 1, "b74fb5a309784a778cb5d14cd6b64ee94da0fd481eef93e9b50fc183ca8b3b1f") -- A Dance of Fire and Ice - Neo Cosmos - Depot 1977574
setManifestid(1977574, "8399953569145511109", 434332000)