-- 4413370's Lua and Manifest Created by Hubcap Manifest
-- Drug Farmer Simulator
-- Created: April 25, 2026 at 12:53:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4413370) -- Drug Farmer Simulator
-- MAIN APP DEPOTS
addappid(4413371, 1, "299931aeba65c7f08c752a1c10d024c05a765ae2383840f5f7f733cfe0cf8c45") -- Depot 4413371
setManifestid(4413371, "6174193124995252192", 2027662876)