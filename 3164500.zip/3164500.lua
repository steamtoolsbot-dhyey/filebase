-- 3164500's Lua and Manifest Created by Hubcap Manifest
-- Schedule I
-- Created: April 17, 2026 at 05:04:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3164500, 1, "dc594c390586e093182147f795ed1ea481969d347bd6a261a3bc83a1066e7fc3") -- Schedule I
-- MAIN APP DEPOTS
addappid(3164501, 1, "81d0de07788de885787b0519b9dabf51618be6cba9124497decf572ac96624f4") -- Depot 3164501
setManifestid(3164501, "2624148878279466820", 7883004354)