-- 220200's Lua and Manifest Created by Hubcap Manifest
-- Kerbal Space Program
-- Created: September 29, 2025 at 20:37:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 35
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(220200, 1, "3a42a764ab5cc99e105f368e08e8c9762964f379cae1c443ac00df56311d9667") -- Kerbal Space Program
-- MAIN APP DEPOTS
addappid(220201, 1, "ebb45304cb6479dd16c67337eb3938a1ef55df437f425c96428701829f4ea17a") -- Kerbal Space Program - PC
setManifestid(220201, "6331816835925954858", 36)
addappid(220202, 1, "9e8e07a271167d65803914cf070937cdcbd2579ce64469a5863b3b9d6b1775e9") -- Kerbal Space Program - OSX
setManifestid(220202, "6145727205642015120", 4977026219)
addappid(220203, 1, "14a5938964e96492302798e26bae7d2956f7cfd3145fba7255a0a9a8ac24605f") -- Kerbal Space Program - Linux
setManifestid(220203, "5744742415595933520", 4985464468)
addappid(220204, 1, "1c02d529a25c71569f3c23f1b4b8593ff1ef2b564ccd0bf476f81f4085aafcf5") -- Kerbal Space Program - Win64
setManifestid(220204, "895421221909357680", 4967323257)
addappid(220211, 1, "43b0893bcbd28d0d2e39a3b5f5aebb69907ec9d529333845e26deba411741316") -- steamworks.net redist common
setManifestid(220211, "3901531883767526193", 171)
addappid(220213, 1, "d33e7273ed3129303b88c8f817432753a38e7b3e63eebb6423f5c61cce5dc859") -- Steamworks.NET LinuxOSXx64
setManifestid(220213, "1660641291841592914", 171)
addappid(220212, 1, "61def03b0ab69e385f5f0d2f8a90900388872b505af866abef3f7277fad257f5") -- Steamworks.NET Winx86
setManifestid(220212, "78739687081486078", 171)
addappid(220214, 1, "9d537f407d93bfdb432575e5167da542f41d93e7fee3d09e1a0e6ce74863754c") -- Steamworks.NET Winx64
setManifestid(220214, "8229629602796981387", 171)
addappid(220216, 1, "0ee55c284a3441c3e8d97b5e45502e52039edf9927404bae341733430ec82a2a") -- KSP Steam Controller Plugin
setManifestid(220216, "9167099533421805932", 171)
addappid(220205, 1, "da4ecd1436c2854f1bdd0e8ca5535ee36204a976535d75028e827f2f78e3a075") -- Spanish 1.3 Localization
setManifestid(220205, "8073598277300090923", 161659003)
addappid(220206, 1, "8b22eb9de912dc70db3d13abbefb6173582184f43035b6797cf49305ad911fb7") -- Russian 1.3 Localization
setManifestid(220206, "939141202072334643", 201505574)
addappid(220207, 1, "8e7bacaf62bed645a727836ac3ca42f47d8fa9b3b7e00b745fd202a0d4e9c713") -- Japanese 1.3 Localization
setManifestid(220207, "8266439066111296104", 319845475)
addappid(220208, 1, "6c0e816856190fa2900bb3147c9bd98a51cea683f4be2b5e92bc3bef46866b40") -- Simplified Chinese 1.3 Localization
setManifestid(220208, "6506278945653714142", 248107655)
addappid(220209, 1, "fe7a8909cc78da952a1f7d0021eeb3df0685f7a6e2e0071411bb21555b117878") -- Portuguese-Brazil 1.3 Localization
setManifestid(220209, "2010052161041755576", 143738086)
addappid(220210, 1, "21ecae68dce08cf59135e4eb49f44799dfdad7c3f28ebd0a16cb35c801114ff7") -- German 1.3 Localization
setManifestid(220210, "5206490517007059532", 168124835)
addappid(220215, 1, "7872bcd108d61924c2273ce9789a8504b38327f1b61363bbe60879e19b435833") -- French 1.3 Localization
setManifestid(220215, "4776840543670162301", 136887011)
addappid(220217, 1, "c8fa2dde08014b438be450aba2b36adde1e4fe856c5a1363a66618ac37315f0f") -- Italian 1.3 Localization
setManifestid(220217, "1542059352249819159", 131052610)
-- DLCS WITH DEDICATED DEPOTS
-- Kerbal Space Program Making History Expansion (AppID: 283740)
addappid(283740)
addappid(283740, 1, "7f076af9d7b24550805795745b696da514bf774de04bc39d12853b31187c970e") -- Kerbal Space Program Making History Expansion - Kerbal Space Program DLC Test Depot
setManifestid(283740, "2443136430323483651", 451678372)
addappid(283744, 1, "280842c2cd82a9df2a2cacb1c37b10fa28447f0ee7fd0888edc16c7e57d81055") -- Kerbal Space Program Making History Expansion - Making_History_IT-IT
setManifestid(283744, "5205655790012932055", 3226262)
addappid(283745, 1, "b6c2082f9a90505b54c4e38fee2436258dabd60a18eef105597469955e201460") -- Kerbal Space Program Making History Expansion - Making_History_RU
setManifestid(283745, "6395620313709645497", 16306822)
addappid(283746, 1, "f171a5a07ab6d5e5ea07cfb2b1e018f9602fbb9419bebdaa30d1e6bbed9bd46e") -- Kerbal Space Program Making History Expansion - Making_History_JA
setManifestid(283746, "7253980953688230007", 2874226)
addappid(283747, 1, "796950ee27d7c06525bfe15279eb67b5913480270020875cf6a9014cf0b49436") -- Kerbal Space Program Making History Expansion - Making_History_ZH-CN
setManifestid(283747, "7329406018471187241", 24589771)
addappid(283748, 1, "b47fb1b25246cb366eecaf11ee5690e728eca21a2545d16c0646a3a57412c96e") -- Kerbal Space Program Making History Expansion - Making_History_FR
setManifestid(283748, "3931195855752949491", 3341784)
addappid(283749, 1, "cfd1ae4cdf043c6130c796ab834eb4dc2f4962012e340674fa9218fc75ebb2cc") -- Kerbal Space Program Making History Expansion - Making_History_DE
setManifestid(283749, "643362983342728812", 3484985)
addappid(283743, 1, "b22533b47510dc54f5cbdeaf941776f1067c037d4865d94bed0fe0f5a58129b0") -- Kerbal Space Program Making History Expansion - Making_History_PT-BR
setManifestid(283743, "7486872015074120441", 3069209)
addappid(807350, 1, "740f402a828bca0f458f283df537b1a34b9053d47a34f6b06873e0c613b03862") -- Kerbal Space Program Making History Expansion - Making_History_ES-ES
setManifestid(807350, "4731056394051162987", 3455798)
-- Kerbal Space Program Breaking Ground Expansion (AppID: 982970)
addappid(982970)
addappid(982970, 1, "d1e8eb87b77ffccaa8d73506918683e65cffb6b70484a354e6fc33c9af99a5fc") -- Kerbal Space Program Breaking Ground Expansion - base
setManifestid(982970, "194154484222638030", 492191935)
addappid(982971, 1, "d51815d2a19e8636db39f73ee4a912e57c29bd096563a9371a048cf850d5a3c3") -- Kerbal Space Program Breaking Ground Expansion - es-es
setManifestid(982971, "2022721560690933980", 4441227)
addappid(982972, 1, "714c53b46b0a34b514696c838f1a9140b9524ca3f894eb40782fc1177ec4eb91") -- Kerbal Space Program Breaking Ground Expansion - ja
setManifestid(982972, "2446219790806602401", 24670101)
addappid(982973, 1, "0a4cddda2dc4ec5e5e9337fe327b25ba6c54b5481bbf70a20006b050cf38636b") -- Kerbal Space Program Breaking Ground Expansion - fr-fr
setManifestid(982973, "5781851745347615732", 5175778)
addappid(982974, 1, "8c5870db783ec68a05c167a73255000a79863940b605af1a0e53375532318357") -- Kerbal Space Program Breaking Ground Expansion - de-de
setManifestid(982974, "3380980933618026025", 5554076)
addappid(982975, 1, "a99f84b5c58617b2991c8943b13fde555b5778582bdcbd7c80ccc66825df409f") -- Kerbal Space Program Breaking Ground Expansion - ru
setManifestid(982975, "14196008539958699", 45271470)
addappid(982976, 1, "9740b760b43733bb193d052c634e6640a2c01e28f13bc9dda0175926484f2699") -- Kerbal Space Program Breaking Ground Expansion - pt-br
setManifestid(982976, "2749404271761332898", 4455138)
addappid(982977, 1, "c0e6ea7d6a4d21b85f7d47908fb932c35a7fb2d14ffd6728a2495bb139e00d4c") -- Kerbal Space Program Breaking Ground Expansion - zh-cn
setManifestid(982977, "3079579928753281626", 159895401)
addappid(982978, 1, "4313fb1a02268516c4ee56e0c4dbc9ccffc2ccc6d23259265bd9f7dc322077f9") -- Kerbal Space Program Breaking Ground Expansion - it-it
setManifestid(982978, "5874266035924219455", 4306388)