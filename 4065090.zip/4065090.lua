-- 4065090's Lua and Manifest Created by Hubcap Manifest
-- 30 Days of Work
-- Created: May 30, 2026 at 02:15:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4065090) -- 30 Days of Work
-- MAIN APP DEPOTS
addappid(4065091, 1, "9c2bee2c920d749ca072aed52700c5f17122551e7a1d9621c54998af44285408") -- Depot 4065091
setManifestid(4065091, "5062443762180202959", 491364777)
-- DLCS WITH DEDICATED DEPOTS
-- 30 Days of Work Artbook (AppID: 4575920)
addappid(4575920)
addappid(4575921, 1, "ff350c392db84d1cd661d17d1df130ffc29684e4b163ff4ea08f54289a9bd8a9") -- 30 Days of Work Artbook - Depot 4575921
setManifestid(4575921, "4484994814148735735", 227729580)